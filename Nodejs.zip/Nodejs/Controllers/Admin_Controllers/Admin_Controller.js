const express = require('express');
const router = express.Router();
const Auth = require('../../Auth/User_Auth/Auth');
const User_Model = require('../../Models/User_Model');
const New_Anime = require('../../Models/New_Anime_Model');
const New_Episode = require('../../Models/New_Episode_Model');
const multer = require('multer');
const path = require('path');

router.get('/Admin', Auth, async (req, res) => {
    if (req.user.member_type != 0) {
        const user_data = await User_Model.find();
        const anime_data = await New_Anime.find();
        // console.log(user_data);
        res.render('Admin.hbs', { 'userdata': user_data, 'animedata':anime_data });

    } else {
        res.redirect('/');
    }

})

router.get('/new_anime_add', Auth, (req, res) => {
    if (req.user.member_type != 0) {
        res.render('New_Anime_Add.hbs');
    } else {
        res.redirect('/');
    }
})


const uploads_video = path.join(__dirname, "../../public/Video");
const thumbnail = path.join(__dirname, "../../public/thumbnail");


// =========================image upload & thumbnail 

// var upload = multer({ dest: "Upload_folder_name" })
// If you do not want to use diskStorage then uncomment it

var storage = multer.diskStorage({
    destination: function (req, file, cb) {

        // Uploads is the Upload_folder_name
        cb(null, thumbnail)
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + "-" + Date.now() + ".jpg")
    }
})

var upload = multer({
    storage: storage,
    // limits: { fileSize: maxSize },
    fileFilter: function (req, file, cb) {

        // Set the filetypes, it is optional
        var filetypes = /jpeg|jpg|png/;
        var mimetype = filetypes.test(file.mimetype);

        var extname = filetypes.test(path.extname(
            file.originalname).toLowerCase());

        if (mimetype && extname) {
            return cb(null, true);
        }

        cb("Error: File upload only supports the "
            + "following filetypes - " + filetypes);
    }

    // mypic is the name of file attribute
});

router.post('/new_anime_add', upload.single('anime_poster'), Auth, async (req, res) => {
    try {
        if (req.user.member_type != 0) {
            const { anime_name, anime_disc, anime_genre, anime_type } = req.body;
            const Newdata = new New_Anime({
                anime_name: anime_name,
                des: anime_disc,
                anime_Genre: anime_genre,
                anime_type: anime_type,
                thubnail: req.file.filename
            });

            const Save_Anime = await Newdata.save();

            if (Save_Anime) {
                res.status(201).send("Successfull data add");
            } else {
                res.status(401).send("Successfull not data add");
            }

        } else {
            res.redirect('/');
        }
    } catch (error) {
        console.log(error)
        res.status(401).redirect('/')
    }

})

// video upload here  

var storage = multer.diskStorage({
    destination: function (req, file, cb) {

        // Uploads is the Upload_folder_name
        cb(null, uploads_video)
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + "-" + Date.now() + ".mp4")
    }
})

var upload = multer({
    storage: storage,
    // limits: { fileSize: maxSize },
    fileFilter: function (req, file, cb) {

        // Set the filetypes, it is optional
        var filetypes = /mp3|mp4/;
        var mimetype = filetypes.test(file.mimetype);

        var extname = filetypes.test(path.extname(
            file.originalname).toLowerCase());

        if (mimetype && extname) {
            return cb(null, true);
        }

        cb("Error: File upload only supports the "
            + "following filetypes - " + filetypes);
    }

    // mypic is the name of file attribute
});

router.get('/new_episode_add', Auth, async(req, res) => {

    if (req.user.member_type != 0) {
        try {
            const Anime_data = await New_Anime.find();
            res.render('New_Episode_Add.hbs', {"anime_data":Anime_data});
        } catch (error) {
            console.log(error);
            res.status(401).send(error);
        }
    } else {
        res.redirect('/');
    }
})

router.post('/new_episode_add', Auth, upload.single('anime_video'), async (req, res) => {
    try {    
    if (req.user.member_type != 0) {
        const { anime_name, anime_ep } = req.body
        const New_Episode_Add = new New_Episode({
            anime_id: anime_name,
            video: req.file.filename,
            Anime_Ep: anime_ep
        })

        const Save_Episode = await New_Episode_Add.save();
        if (Save_Episode) {
            res.status(201).send("succ");
        } else {
            res.status(401).send("not succ");
        }

    } else {
        res.redirect('/');
    }
} catch (error) {
 console.log(error);
 res.status(401).send(error);       
}
})


router.get('/profile', Auth, (req, res) => {
    if (req.user.member_type != 0) {
        res.render('Profile.hbs');
    } else {
        res.redirect('/');
    }
})


module.exports = router;