const express = require('express');
const router = express.Router();
const User_model = require('../../Models/User_Model');
const New_Anime = require('../../Models/New_Anime_Model');
const New_Episode = require('../../Models/New_Episode_Model');
const Auth = require('../../Auth/User_Auth/Auth');
const fs = require('fs');

const path = require('path');


router.get('/', Auth, async (req, res) => {
    const Anime_data = await New_Anime.find();
    res.render('home.hbs', { is_auth: true, 'animedata': Anime_data });
})

router.get('/register', (req, res) => {
    res.render('Register.hbs');
})

// register is here 

router.post('/register', async (req, res) => {
    const { name, email, password } = req.body;
    try {
        const find_One = await User_model.findOne({ email });
        if (find_One) {
            res.status(401).send("Email is already exits")
        } else {
            const User_Create = new User_model({
                name: name,
                email: email,
                password: password,
            })


            const token = await User_Create.getToken();
            const User_save = await User_Create.save();

            if (User_save) {
                res.status(201).redirect('/login');
            } else {
                res.status(401).send("User Not Created Successfull !");
            }
        }


    } catch (error) {
        console.log(error);
    }
})





router.get('/login', (req, res) => {
    res.render('login.hbs');
})

router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const find_Email = await User_model.findOne({ email });
        const token = await find_Email.getToken();
        res.cookie("jwt", token, {
            httpOnly: true
        });

        if (find_Email.password == password) {
            if (find_Email.member == '0') {
                res.redirect('/');
            } else {
                res.redirect('/Admin');
            }
        } else {
            res.status(401).send('login not successfull !');
        }
    } catch (error) {
        console.log('error ', error)
        res.status(401).send("login error");
    }
})


router.get('/logout', Auth, async (req, res) => {
    try {
        // console.log(req.user)
        req.user.tokens = req.user.tokens.filter((v) => {
            return v.token != req.token;
        });
        res.clearCookie('jwt');
        await req.user.save();
        res.status(201).redirect('/login');
    } catch (error) {
        console.log(error);
    }
})

// All anime here 
router.get('/Anime', async (req, res) => {
    res.render('Anime.hbs');
})


router.get('/Anime/:Anime_name', async (req, res) => {
    try {
        console.log(req.params.Anime_name);
        const id = req.params.Anime_name;
        const Animedata = await New_Anime.findById({ _id: id });
        const Anime_ep = await New_Episode.find({ anime_id: id });
        console.log(Anime_ep)
        res.render('Single_Anime_page.hbs', { 'anime_data': Animedata, 'anime_ep': Anime_ep });
    } catch (error) {
        console.log(error);
        res.status(201).send(error);
    }
})

router.get('/Anime/:Anime_name/:anime_ep', Auth, async (req, res) => {

    try {
        const id = req.params.anime_ep;
        const video_ep = await New_Episode.findOne({ _id: id })
        res.render('Anime_Streaming.hbs', { 'anime_ep': video_ep })
    } catch (error) {
        console.log(error);
        res.status(401).send(error);
    }



})
router.get('/video/:id', async (req, res) => {
    try {
        const range = req.headers.range;
        const id = req.params.id;
        console.log(id)
        const video = await New_Episode.findOne({ _id: id });
        console.log(video)


        if (!range) {
            res.status(400).send("Request error !");
        }

        const video_path = path.join(__dirname, `../../public/Video/${video.video}`);
        const video_size = fs.statSync(video_path).size;

        const Chunkdata_send = 10 ** 6 // 1000000 = 1 MB
        const start = Number(range.replace(/\D/g, ""));
        // console.log(start);
        const end = Math.min(start + Chunkdata_send, video_size - 1);
        const contentLength = end - start + 1;
        const headers = {
            "Content-Range": `bytes ${start}-${end}/${video_size}`,
            "Accept-Range": 'bytes',
            "Content-Length": contentLength,
            "Content-Types": "video/mp4"
        }
        res.writeHead(206, headers);
        const videoStream = fs.createReadStream(video_path, { start, end });
        videoStream.pipe(res);
    } catch (error) {
        console.log(error);
        res.status(401).send(error)
    }

})




module.exports = router;