const mongoose = require('mongoose');

const connection = async () => {
    await mongoose.connect('mongodb+srv://saifali972331:CPYPfjJlac4RGGcI@anime.coemtha.mongodb.net/anime?retryWrites=true&w=majority');
    console.log('connection succ !');
}


connection();
module.exports = mongoose;