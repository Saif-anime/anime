const mongoose = require('mongoose');

const New_Episode_Schema = new mongoose.Schema({
    anime_id: {
        type: String,
        required: true,
    },
    video: {
        type: String,
        required: true
    },
    Anime_Ep:{
        type:String,
        required:true,
        default:0
    },
    is_active: {
        type: String,
        reqired: true,
        default: 1
    },
    date: {
        type: String,
        required: true,
        default: new Date().toLocaleDateString(),
    }
})

const New_Episode = mongoose.model('New_Episode', New_Episode_Schema);


module.exports = New_Episode;
