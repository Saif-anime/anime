const mongoose = require('mongoose');

const New_Anime_Schema = new mongoose.Schema({
    anime_name: {
        type: String,
        required: true,
        min: 3
    },
    des: {
        type: String,
        required: true,
    },
    anime_Genre:{
        type:String,
        required:true
    },
    anime_type: {
        type: String,
        required: true,
    },
    thubnail: {
        type: String,
        required: true,
    },
    is_active: {
        type: String,
        reqired: true,
        default: 1
    },
    date: {
        type: String,
        required: true,
        default: new Date().toLocaleDateString(),
    }
})

const New_Anime = mongoose.model('New_Anime', New_Anime_Schema);


module.exports = New_Anime;