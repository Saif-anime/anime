const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const User_Schema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        min: 3
    },
    email: {
        type: String,
        required: true,
    },
    member_type: {
        type: String,
        required: true,
        default: 0
    },
    password: {
        type: String,
        required: true,
        min: 3
    },
    is_active: {
        type: Boolean,
        required: true,
        default: true
    }
    ,
    tokens: [{
        token: {
            type: String,
            required: false
        }
    }]
})

User_Schema.methods.getToken = async function () {
    try {
        const token = jwt.sign({ _id: this._id.toString() }, process.env.SECRET_KEY);
        this.tokens = this.tokens.concat({ token: token });
        await this.save();
        return token;
    } catch (error) {
        console.log(error);
        res.status(401).send('not generate jwt')
    }
}

const User = mongoose.model('User', User_Schema);


module.exports = User;