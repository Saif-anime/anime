require('dotenv').config()
const express = require('express');
const app = express();
const port = process.env.PORT || 8000;
const hbs = require('hbs');
const cookie_parser = require('cookie-parser');
app.use(cookie_parser());
const path = require('path');
app.use(express.json());
app.use(express.urlencoded({extended:false}))
require('./conn');

const UserController = path.join(__dirname, "./Controllers/User_Controller/User_Controller.js");
const User_Controller = require(UserController);
const AdminController = path.join(__dirname, "./Controllers/Admin_Controllers/Admin_Controller.js");
const Admin_Controller = require(AdminController);



app.use(express.static('public'))
app.set('view engine', 'hbs');

const template = path.join(__dirname, "./views/template");
const partial = path.join(__dirname, "./views/partial");


hbs.registerPartials(partial);

// generate helper if equil
hbs.registerHelper('if_eq', function(a, b, opts) {
  if (a == b) {
      return opts.fn(this);
  } else {
      return opts.inverse(this);
  }
});

hbs.registerHelper('trimString', function(passedString) {
  var theString = passedString.substring(0,150);
  return new hbs.SafeString(theString)
});


app.set('views', template)

app.use(User_Controller);
app.use(Admin_Controller);





app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})